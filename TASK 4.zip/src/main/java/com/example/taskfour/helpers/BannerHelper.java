package com.example.taskfour.helpers;

import android.app.Activity;
import android.view.View;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class BannerHelper {
    public static void loadBanner(Activity activity, int adViewId) {
        View v = activity.findViewById(adViewId);
        if (v instanceof AdView) {
            AdView adView = (AdView) v;
            // Use remote banner id if loaded; otherwise adView may already have id in xml
            String unit = FirebaseAdHelper.getBannerId();
            if (unit != null && !unit.isEmpty()) {
                adView.setAdUnitId(unit);
            }
            adView.loadAd(new AdRequest.Builder().build());
        }
    }
}
