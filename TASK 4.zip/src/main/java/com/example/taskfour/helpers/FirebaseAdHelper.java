package com.example.taskfour.helpers;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class FirebaseAdHelper {

    public interface OnIdsLoaded {
        void onLoaded(Map<String, String> ids);
        void onError(Exception e);
    }

    private static Map<String, String> cached = null;

    public static void fetchAdUnitIds(OnIdsLoaded cb) {
        try {
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ad_units");
            ref.get().addOnSuccessListener(snapshot -> {
                Map<String, String> ids = new HashMap<>();
                if (snapshot.exists()) {
                    for (DataSnapshot child : snapshot.getChildren()) {
                        Object v = child.getValue();
                        if (v != null) ids.put(child.getKey(), String.valueOf(v));
                    }
                }
                cached = ids;
                cb.onLoaded(ids);
            }).addOnFailureListener(e -> {
                cb.onError(e);
            });
        } catch (Exception e) {
            cb.onError(e);
        }
    }

    public static Map<String, String> getCached() {
        return cached;
    }

    public static void storeIds(Map<String, String> ids) {
        cached = ids;
    }

    public static String getBannerId() {
        if (cached != null && cached.get("banner") != null) return cached.get("banner");
        return "ca-app-pub-3940256099942544/6300978111"; // test banner
    }

    public static String getInterstitialId() {
        if (cached != null && cached.get("interstitial") != null) return cached.get("interstitial");
        return "ca-app-pub-3940256099942544/1033173712"; // test interstitial
    }

    public static String getAppOpenId() {
        if (cached != null && cached.get("app_open") != null) return cached.get("app_open");
        return "ca-app-pub-3940256099942544/9257395921"; // test app open
    }
}
