package com.example.taskfour.helpers;

import android.app.Activity;
import android.app.Application;
import androidx.annotation.MainThread;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.LoadAdError;

public class AppOpenAdManager {
    private AppOpenAd appOpenAd = null;
    private boolean isLoading = false;
    private final Application app;
    private final String adUnit;
    private Activity currentActivity;

    public AppOpenAdManager(Application app, String adUnit) {
        this.app = app;
        this.adUnit = adUnit;
    }

    public void fetchAd() {
        if (isLoading || appOpenAd != null) return;
        isLoading = true;
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(app, adUnit, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        appOpenAd = ad;
                        isLoading = false;
                    }
                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        isLoading = false;
                    }
                });
    }

    @MainThread
    public void show(Activity activity, Runnable onComplete) {
        if (appOpenAd != null) {
            appOpenAd.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    appOpenAd = null;
                    fetchAd(); // preload next
                    onComplete.run();
                }
                @Override
                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    appOpenAd = null;
                    onComplete.run();
                }
            });
            appOpenAd.show(activity);
        } else {
            // not loaded -> run callback immediately
            onComplete.run();
            fetchAd();
        }
    }
}
