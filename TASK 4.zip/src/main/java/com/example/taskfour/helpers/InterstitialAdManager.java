package com.example.taskfour.helpers;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class InterstitialAdManager {
    private InterstitialAd interstitialAd = null;
    private boolean isLoading = false;

    public void load(Activity activity) {
        if (isLoading || interstitialAd != null) return;
        isLoading = true;
        AdRequest req = new AdRequest.Builder().build();
        InterstitialAd.load(activity, FirebaseAdHelper.getInterstitialId(), req, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd ad) {
                interstitialAd = ad;
                isLoading = false;
            }
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                interstitialAd = null;
                isLoading = false;
            }
        });
    }

    public void showIfReady(Activity activity, Runnable onDone) {
        if (interstitialAd == null) {
            onDone.run();
            return;
        }
        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                interstitialAd = null;
                onDone.run();
            }
            @Override
            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                interstitialAd = null;
                onDone.run();
            }
        });
        interstitialAd.show(activity);
    }
}
