package com.example.taskfour;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.taskfour.ScreenFourActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ScreenThreeActivity extends AppCompatActivity {

    private AdView adViewScreen4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_four);

        adViewScreen4 = findViewById(R.id.adViewScreen4);
        Button btnNext = findViewById(R.id.btnNext4);

        // Load Ad
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewScreen4.loadAd(adRequest);

        // Navigate to Screen 5
        btnNext.setOnClickListener(v ->
                startActivity(new Intent(ScreenThreeActivity.this, ScreenFourActivity.class))
        );
    }
}
