package com.example.taskfour;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.taskfour.R;
import com.example.taskfour.ScreenTwoActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ScreenOneActivity extends AppCompatActivity {

    private AdView adViewScreen2;
    private Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivty_screen);

        // Initialize Views
        adViewScreen2 = findViewById(R.id.adViewScreen2);
        btnNext = findViewById(R.id.btnNext);

        // Load Banner Ad
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewScreen2.loadAd(adRequest);

        // Go to Screen 3
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScreenOneActivity.this, ScreenTwoActivity.class);
                startActivity(intent);
            }
        });
    }
}
