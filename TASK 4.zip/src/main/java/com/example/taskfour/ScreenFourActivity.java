package com.example.taskfour;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ScreenFourActivity extends AppCompatActivity {

    private AdView adViewScreen5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_five);

        adViewScreen5 = findViewById(R.id.adViewScreen5);
        Button btnFinish = findViewById(R.id.btnFinish);

        // Load Ad
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewScreen5.loadAd(adRequest);

        // Finish the activity
        btnFinish.setOnClickListener(v -> finish());
    }
}
