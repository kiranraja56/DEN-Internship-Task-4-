package com.example.taskfour;

import android.app.Application;
import com.example.taskfour.helpers.AppOpenAdManager;

public class MyApplication extends Application {

    private AppOpenAdManager appOpenAdManager;

    @Override
    public void onCreate() {
        super.onCreate();

        // Replace this with your real AdMob App Open Ad unit ID
        String adUnitId = "ca-app-pub-3940256099942544/3419835294"; // Test ID
        appOpenAdManager = new AppOpenAdManager(this, adUnitId);

        // Optionally, preload the first ad immediately
        appOpenAdManager.fetchAd();
    }

    public AppOpenAdManager getAppOpenAdManager() {
        return appOpenAdManager;
    }
}
