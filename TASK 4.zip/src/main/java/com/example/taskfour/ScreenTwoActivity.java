package com.example.taskfour;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.taskfour.R;
import com.example.taskfour.ScreenThreeActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ScreenTwoActivity extends AppCompatActivity {

    private AdView adViewScreen3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_three);

        adViewScreen3 = findViewById(R.id.adViewScreen3);
        Button btnNext = findViewById(R.id.btnNext3);

        // Load Ad
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewScreen3.loadAd(adRequest);

        // Navigate to Screen 4
        btnNext.setOnClickListener(v ->
                startActivity(new Intent(ScreenTwoActivity.this, ScreenThreeActivity.class))
        );
    }
}
